import re
import os
import random

class ExtractTestData:
    def __init__(self):
        pass

    def getTrainingData(self, training_filename, test_filename, new_training_filename, test_untagged_filename):
        separator = '\n\n'
        fh = open(training_filename, 'r')
        contents = fh.read()
        listOfSentences = re.split(separator, contents)
        random.shuffle(listOfSentences)
        testList = []

        '''
            Can convert the below lines of code into 
            random.
        '''

        for i in range(0,1500):
            testList.append(listOfSentences[i])
        
        for i in range(10000, 11500):
            testList.append(listOfSentences[i])

        del listOfSentences[0:1500] 
        del listOfSentences[10000:11500] 
        
        '''
            File operations
        '''
        fh1 = open(test_filename, 'w')
        fh1.writelines("%s\n\n" % item for item in testList)
        fh1.close()

        os.system ("cp %s %s" %(test_filename, test_untagged_filename))
        os.system ("sed -i -r 's/(\s+)?\S+//3' %s" % test_untagged_filename)

        fh2 = open(new_training_filename, 'w')
        fh2.writelines("%s\n\n" % item for item in listOfSentences)
        fh.close()


e = ExtractTestData()
#e.getTrainingData("berp-POS-training.txt", "berp-POS-test.txt", "berp-POS-training-new.txt", "berp-POS-test-untagged.txt")
e.getTrainingData("gene-trainF17.txt", "gene-testF17.txt", "gene-trainF17-new.txt", "gene-testF17-untagged.txt")

